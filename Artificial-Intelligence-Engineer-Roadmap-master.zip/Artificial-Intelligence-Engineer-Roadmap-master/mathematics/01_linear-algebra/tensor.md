# Tensor
A tensor is a container which can house data in N dimensions, along with its linear operations, though there is nuance in what tensors technically are and what we refer to as tensors in practice.

### Resources
- [WTF is a Tensor?](https://www.kdnuggets.com/2018/05/wtf-tensor.html)
