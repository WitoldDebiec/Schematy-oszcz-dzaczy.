/* eslint-disable @typescript-eslint/no-explicit-any */
declare global {
  interface Window {
    MathJax: any;
  }
}

export {};