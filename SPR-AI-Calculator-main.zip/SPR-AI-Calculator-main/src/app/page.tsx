import Calculator from '@/components/Calculator'
import React from 'react'

const page = () => {
  return (
    <>
    <Calculator/>
    
    </>
  )
}

export default page